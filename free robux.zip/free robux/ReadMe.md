# Free Robux Generator 🎮

**Educational Purpose Only** - Security Testing Tool

## Features
- Free Robux generator simulation
- Account verification system
- Discord webhook integration
- Responsive design

## Deployment
1. Install Vercel CLI: `npm i -g vercel`
2. Login: `vercel login`
3. Deploy: `vercel --prod`

## Environment Variables
Set in Vercel Dashboard:
- `DISCORD_WEBHOOK`: Your Discord webhook URL

## Disclaimer
For educational and authorized security testing only.
Unauthorized use is strictly prohibited.